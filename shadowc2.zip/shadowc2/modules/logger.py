
import logging
import os

log_path = "logs"
os.makedirs(log_path, exist_ok=True)

logging.basicConfig(
    filename=os.path.join(log_path, 'c2.log'),
    format='[%(asctime)s] %(levelname)s: %(message)s',
    level=logging.INFO
)

def log_info(msg):
    logging.info(msg)

def log_error(msg):
    logging.error(msg)
