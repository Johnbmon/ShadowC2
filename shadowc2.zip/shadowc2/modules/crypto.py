
from cryptography.fernet import Fernet

key = Fernet.generate_key()
cipher = Fernet(key)

def encrypt_message(message: str) -> bytes:
    return cipher.encrypt(message.encode('utf-8'))

def decrypt_message(token: bytes) -> str:
    return cipher.decrypt(token).decode('utf-8')

def get_key() -> bytes:
    return key
