
from modules.crypto import encrypt_message, decrypt_message
from modules.logger import log_info, log_error

def send_command(sock, command: str) -> bool:
    try:
        encrypted = encrypt_message(command)
        sock.send(encrypted)
        log_info(f"Sent command: {command}")
        return True
    except Exception as e:
        log_error(f"Send failed: {e}")
        return False

def receive_response(sock, buffer_size=4096) -> str:
    try:
        response = sock.recv(buffer_size)
        decrypted = decrypt_message(response)
        log_info(f"Received: {decrypted}")
        return decrypted
    except Exception as e:
        log_error(f"Receive failed: {e}")
        return f"[!] Error: {e}"
