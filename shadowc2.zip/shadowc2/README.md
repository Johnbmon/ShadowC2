# ShadowC2

A lightweight, encrypted C2 framework for ethical hacking and cybersecurity research.
